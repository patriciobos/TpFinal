/*
 * luz_sensor.h
 *
 *  Created on: 29/11/2011
 *      Author: alejandro
 */

#ifndef GAS_SENSOR_H_
#define GAS_SENSOR_H_

#include "modulos.h"

void ManejadorEventosArbitro (Evento_t *evn);

#endif /* LUZ_SENSOR_H_ */
