
#include "FrameworkEventos.h"
#include "includes.h"

typedef enum EstadosGasSensorEnum {
	sARBITRO_IDLE		 = 0,
	sARBITRO_INACTIVO		,
	sARBITRO_MIDIENDO		,
	sARBITRO_ALARMA
} EstadosGasSensorEnum_t;

static int 			estado = sARBITRO_INACTIVO;
static int 			estadoAnterior;
static Modulo_t * 	mod;


extern char datoString[4];

extern xQueueHandle colaMensajesSalientesRadio;
extern xQueueHandle colaDatosParaServidorWeb;

static void ModuloArbitroInit(Modulo_t * pModulo);

void ManejadorEventosArbitro (Evento_t *evn)
{
	int mensajeCola;
	switch(estado)
	{
//-----------------------------------------------------------------------------
		case sARBITRO_INACTIVO:
			switch(evn->signal)
			{
				case SIG_MODULO_INICIAR:
					mod = (Modulo_t *)evn->valor;
					ModuloArbitroInit(mod);
//					estado = sARBITRO_MIDIENDO;
					estado = sARBITRO_IDLE;
					break;

				default:
					break;
			}
			break;
//-----------------------------------------------------------------------------
		case sARBITRO_MIDIENDO:
			switch(evn->signal)
			{
				case SIG_TIMEOUT:
					mensajeCola 	= DATA_REQUEST;
					xQueueSend		(colaMensajesSalientesRadio, &mensajeCola, 0);
					TimerArmUnico	(mod, mod->periodo);
					break;

				case SIG_DATO_RECIBIDO:
					xQueueSend		(colaDatosParaServidorWeb, evn, 0);
					break;

				case SIG_ALARMA_RECIBIDA:
					estadoAnterior	= estado;
					estado 			= sARBITRO_ALARMA;
					TimerDisarm		(mod);
					mensajeCola		= evn->signal;
					xQueueSend		(colaDatosParaServidorWeb, &mensajeCola, 0);
					break;

				case SIG_PARAR_MEDICIONES:
					estado 			= sARBITRO_IDLE;
					TimerDisarm		(mod);
					break;

				case SIG_RESETEAR_ALARMA:
					mensajeCola 	= ALARM_RESET;
					xQueueSend		(colaMensajesSalientesRadio, &mensajeCola, 0);
					break;

				default:
					break;
			}
			break;
//------------------------------------------------------------------------------
		case sARBITRO_ALARMA:
			switch(evn->signal)
			{
				case SIG_RESETEAR_ALARMA:
					estado = estadoAnterior;
					mensajeCola 	= ALARM_RESET;
					xQueueSend		(colaMensajesSalientesRadio, &mensajeCola, 0);
					if(estadoAnterior == sARBITRO_MIDIENDO)
					{
						TimerArmUnico	(mod, mod->periodo);
					}
					break;

				default:
					break;
			}
			break;
//-----------------------------------------------------------------------------
		case sARBITRO_IDLE:
			switch(evn->signal)
			{
				case SIG_INICIAR_MEDICIONES:
					estado = sARBITRO_MIDIENDO;
					mod->periodo = (int*)(evn->valor);
					TimerArmUnico (mod, mod->periodo);
					break;

				case SIG_ALARMA_RECIBIDA:
					estadoAnterior	= estado;
					estado 			= sARBITRO_ALARMA;
					mensajeCola		= evn->signal;
					TimerDisarm		(mod);
					xQueueSend		(colaDatosParaServidorWeb, evn, 0);
					break;

				default:
					break;
			}
			break;

//-----------------------------------------------------------------------------
		default:
			// Estados en los que no tengo que manejar eventos
			break;
//-----------------------------------------------------------------------------
	}
}

static void ModuloArbitroInit(Modulo_t * pModulo)
{
	pModulo->periodo = 1000;
	TimerArmUnico(pModulo, pModulo->periodo);
}
