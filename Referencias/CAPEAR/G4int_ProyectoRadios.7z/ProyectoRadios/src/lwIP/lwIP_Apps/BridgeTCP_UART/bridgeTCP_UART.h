/*
 * bridgeTCP_UART.h
 *
 *  Created on: 22/11/2013
 *      Author: Alejandro
 */

#ifndef BRIDGETCP_UART_H_
#define BRIDGETCP_UART_H_

void InitBridgeTCP_UART ( void );

#endif /* BRIDGETCP_UART_H_ */
