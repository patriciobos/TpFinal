/*
 * RuntimeStats.h
 *
 *  Created on: 22/11/2013
 *      Author: Alejandro
 */

#ifndef RUNTIMESTATS_H_
#define RUNTIMESTATS_H_

void 		vMainConfigureTimerForRunTimeStats	( void );
uint32_t 	ulMainGetRunTimeCounterValue		( void );

#endif /* RUNTIMESTATS_H_ */
