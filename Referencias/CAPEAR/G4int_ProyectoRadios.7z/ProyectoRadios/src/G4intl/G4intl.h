//#include G4intl.c

char stemp[100];
char inputx[15],accion[15];


void pointer2string(char *pointer, char string[]);
char* substring(const char string[],int inicio,int longitud);
int stringcompare(const char s1[], const char s2[]);

void extraer_variables_GET(char* p);

int extraer_parametros(char* entrada);

void accionArbitro(char* accion,char* inputx);
