//CAPI
#include "lpc_176X_PeriphNames.h"
#include "lpc_176X_PinNames.h"
#include "GPIO.h"
#include "UART.h"
UART Consola;
GPIO led;

/* Standard includes. */
#include <string.h>

/* FreeRTOS includes. */
#include "FreeRTOS.h"
#include "task.h"

#include "Arbitro/Arbitro.h"

/* lwIP includes. */
#include "lwip/tcpip.h"

#include "AHBRAM.h"
//-----------------------------------------------------------------------------
#include "includes.h"
#define PANID			1
#define ADDR_BROADCAST 	0
#define ADDR_LOCAL		1
#define ADDR_REMOTO		2
//-----------------------------------------------------------------------------
static void Heartbeat 			( void* pvParameters ); //Destello un led
extern void lwIPAppsInit		( void *pvArguments );	/* Defined in lwIPApps.c. */
static void prvSetupHardware	( void );

//------------------------------------------------------------------------------

#include "FrameworkEventos.h"
Modulo_t * ModuloArbitro;
xQueueHandle colaEventosPrioridadBaja;
xQueueHandle colaMensajesSalientesRadio;
xQueueHandle colaDatosParaServidorWeb;
void TareaCommRadio (void * pvParamas);

//------------------------------------------------------------------------------

int main( void )
{
	prvSetupHardware();

	colaEventosPrioridadBaja 	= xQueueCreate(8, sizeof(Evento_t));
	colaDatosParaServidorWeb 	= xQueueCreate(8, sizeof(Evento_t));
	colaMensajesSalientesRadio 	= xQueueCreate(8, sizeof(int));

	xTaskCreate(
			TareaDespachadoraEventos,			/* Pointer to the function that implements the task. */
			(signed char *)"Control",			/* Text name for the task.  This is to facilitate debugging only. */
			5 * configMINIMAL_STACK_SIZE,		/* Stack depth in words. */
			(void*) colaEventosPrioridadBaja,	/* Parametro de la tarea */
			PRIORIDAD_BAJA,						/* Prioridad */
			NULL );								/* Task handle. */

	xTaskCreate(
			TareaCommRadio,						/* Pointer to the function that implements the task. */
			(signed char *)"Control2",			/* Text name for the task.  This is to facilitate debugging only. */
			5 * configMINIMAL_STACK_SIZE,		/* Stack depth in words. */
			(void*) NULL,						/* Parametro de la tarea */
			PRIORIDAD_BAJA,						/* Prioridad */
			NULL );								/* Task handle. */

	ModuloArbitro = RegistrarModulo(ManejadorEventosArbitro, PRIORIDAD_BAJA);

	IniciarTodosLosModulos();

	//xTaskCreate	( Heartbeat, (signed char *)"Heartbeat", configMINIMAL_STACK_SIZE, NULL, PRIORIDAD_ALTA, NULL);
	tcpip_init	( lwIPAppsInit, NULL ); // This call creates the TCP/IP thread.

	vTaskStartScheduler();

	for( ;; );
}

static void prvSetupHardware( void )
{
	UARTInit(&Consola, UART_3, 115200, 8, 'n', 1);
	UARTputs(&Consola, "Uart OK", UART_PUTS_INTERRUPCIONES);

	GPIO_Init(&led, SALIDA, ALTO, GPIO__0_22);

	while(ccInit(PANID, ADDR_LOCAL, ADDR_LOCAL, 0)<0);

	/* The examples assume that all priority bits are assigned as preemption priority bits. */
	NVIC_SetPriorityGrouping( 0UL );

	/* Force some large data structures into AHB RAM to keep the calculated flash+RAM code size down. */
	prvManuallyPlaceLargeDataInAHBRAM();
}

//-----------------------------------------------------------------------------

void TareaCommRadio (void * pvParamas)
{
	frameData tx,rx;
	u16 data = 0;
	RFPacket_type packet_type;

	volatile portTickType tiempo_ON  = 200/portTICK_RATE_MS;
//	volatile portTickType periodo = 200/portTICK_RATE_MS;

	portTickType ticks = xTaskGetTickCount();



	int mensaje;
	while(1)
	{
		xQueueReceive(colaMensajesSalientesRadio, &mensaje, portMAX_DELAY);
		switch(mensaje)
		{
			case DATA_REQUEST:			//Transmitir
				tx.src.shortAddr.panid	= PANID;
				tx.src.shortAddr.addr 	= ADDR_LOCAL;
				tx.dst.shortAddr.panid	= PANID;
				tx.dst.shortAddr.addr 	= ADDR_REMOTO;

				tx.fcf = ccWrapperFCF(MAC_FRAME_TYPE_DATA, 0, 0, 1, 0,
						MAC_ADDR_MODE_SHORT, 0, MAC_ADDR_MODE_SHORT);

				packet_type 			= DATA_REQUEST;
				data 					= 0;
				encodePayload(tx.payload, &packet_type, &data);
				tx.pl_length = 3;

				ccFrameTx(tx);

				Activar(&led);
				vTaskDelay(tiempo_ON);
				Pasivar(&led);
//				vTaskDelayUntil(&ticks,periodo);

//				rx = ccFrameRx();
				rx = ccFrameRxTimeOut(150);

//				if(!strcmp(rx.payload,"timeout"))
				if(rx.payload[4]==1)
				{
					packet_type=DATA_SENT;
					data=-1;
				}
				else decodePayload(rx.payload, &packet_type, &data);

				switch(packet_type)
				{
					case ALARM_SET:
						EncolarEvento(ModuloArbitro, SIG_ALARMA_RECIBIDA, 0);
						break;

					case DATA_SENT:
						EncolarEvento(ModuloArbitro, SIG_DATO_RECIBIDO, data);
						break;

					default:
						break;
				}
				break;

			case ALARM_RESET:
				packet_type 			= ALARM_RESET;
				data 					= 0;
				encodePayload(tx.payload, &packet_type, &data);
				tx.pl_length = 3;

				ccFrameTx(tx);

				Activar(&led);
				vTaskDelay(tiempo_ON);
				Pasivar(&led);
				break;


			default:
				break;
		}
	}
}

#if 1 //Hooks
void vApplicationMallocFailedHook( void )
{
	taskDISABLE_INTERRUPTS();
	for( ;; );
}

void vApplicationStackOverflowHook( xTaskHandle pxTask, signed char *pcTaskName )
{
	( void ) pcTaskName;
	( void ) pxTask;

	taskDISABLE_INTERRUPTS();
	for( ;; );
}

//NO se usan en esta aplicacion
void vApplicationIdleHook( void )
{

}
#endif

static void Heartbeat (void* pvParameters)
{
	GPIO Rojo, Verde, Azul;
	GPIO_Init(&Rojo, 	SALIDA, ALTO, EABASE_RGB_ROJO);
	GPIO_Init(&Verde, 	SALIDA, ALTO, EABASE_RGB_VERDE);
	GPIO_Init(&Azul, 	SALIDA, ALTO, EABASE_RGB_AZUL);

	while(1)
	{
		isActivo(&Rojo) ? Pasivar(&Rojo) : Activar (&Rojo);
		vTaskDelay(500 / portTICK_RATE_MS);
	}
}
