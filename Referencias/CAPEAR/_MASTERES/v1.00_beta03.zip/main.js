


/*
========================================================

****   PROYECTO CAPEAR - Programas "browser-side"  *****

========================================================
*/


/* VARIABLES GLOBALES */

//cotas
RDLAYmin=1;	RDLAYmax=30;
RPERImin=2;	RPERImax=99;
RTRIGmin=1;	RTRIGmax=5;

//valores por defecto
var dIP___='0.0.0.0';
var dHR_ON='00:00';
var dHR_OF='23:59';
var dRDLAY='1';
var dRPERI='4';
var dRTRIG='2';

//se�aladores de error
var vIP___=1;
var vHR_ON=1;
var vHR_OF=1;
var vHR_ID=1;
var vRDLAY=1;
var vRPERI=1;
var vRTRIG=1;

//variables de validaci�n
var todo_ok=false;

//Mensajes
var MSJ_VAL_VALIDO='Por favor, ingresar un valor v�lido.';


/* FUNCIONES */

function JavaScriptEnabled()	// saca el cartel destinado a los que no soportan JavaScript
{
	document.getElementById('NoJavaScript').style.display='none';
	return;
	}


function habilitar_config(SN)	//SN es 1 o 0
{
	if (SN==0)	document.getElementById('config').style.display='none'
	      else	document.getElementById('config').style.display='inline-block';
	return;
	}


function habilitar_puerto(N)	//N es el # de puerto
{
	var VACTPT=document.getElementById('ACTPT'+N).checked;
	if(VACTPT!=true) {	//deshabilito
		document.getElementById('STATU'+N).setAttribute('style','color:#ACA899');		
		document.getElementById('STATU'+N).innerHTML="N/A";		
		document.getElementById('IP___'+N).disabled=true;		
		document.getElementById('SWMAN'+N).disabled=true;		
		document.getElementById('RTCMD'+N).disabled=true;		
		document.getElementById('HR_ON'+N).disabled=true;		
		document.getElementById('HR_OF'+N).disabled=true;		
		document.getElementById('RDLAY'+N).disabled=true;		
		document.getElementById('RAUTO'+N).disabled=true;		
		document.getElementById('RPERI'+N).disabled=true;		
		document.getElementById('RTRIG'+N).disabled=true;		
		} else {	//habilito
		document.getElementById('STATU'+N).setAttribute('style','color:#000000');		
		document.getElementById('STATU'+N).innerHTML="N/D";		
		document.getElementById('IP___'+N).disabled=false;		
		document.getElementById('SWMAN'+N).disabled=false;		
		document.getElementById('RTCMD'+N).disabled=false;		
		/* HR_ON, HR_OF, RDLAY				*/
	 	document.getElementById('RAUTO'+N).disabled=false;		
		/* RPERI, RTRIG 				*/
		}
	return;
	}


function seleccion_de_modos(N)	//N es el # de puerto
{
	var VRTCMD=document.getElementById('RTCMD'+N).value;
	var VRAUTO=document.getElementById('RAUTO'+N).checked;
	switch(VRTCMD) {
		case 'DESAC':
			document.getElementById('HR_ON'+N).disabled=true;					
			document.getElementById('HR_OF'+N).disabled=true;		
			document.getElementById('RDLAY'+N).disabled=!VRAUTO;
			break;
		case 'ONOFF':
			document.getElementById('HR_ON'+N).disabled=false;					
			document.getElementById('HR_OF'+N).disabled=false;		
			document.getElementById('RDLAY'+N).disabled=!VRAUTO;
			break;
		case 'RESET':
			document.getElementById('HR_ON'+N).disabled=true;					
			document.getElementById('HR_OF'+N).disabled=false;		
			document.getElementById('RDLAY'+N).disabled=false;
			break;
		}
		document.getElementById('RPERI'+N).disabled=!VRAUTO;
		document.getElementById('RTRIG'+N).disabled=!VRAUTO;
	return;
	}


function truchar_estado(N)	//N es el # de puerto
{
	document.getElementById('STATU'+N).setAttribute('style','color:#000000');
	var VSTAT=document.getElementById('STATU'+N).innerHTML;
	if(VSTAT=='ON') {
		document.getElementById('SWMAN'+N).value='PRENDER';		
		document.getElementById('STATU'+N).innerHTML='OFF';
		} else {
		document.getElementById('SWMAN'+N).value='APAGAR';		
		document.getElementById('STATU'+N).innerHTML='ON';
		}
	return;
	}


function listar_puerto(N)	//N es el # de puerto
{
	var L='';

L=L+'	<!--Puerto# '+N+' -->															';
L=L+'																		';
L=L+'	<tr class="puerto" onChange="verifica_datos_ingresados('+N+');">									';
L=L+'	<th>'+N+' <input type="checkbox" name="ACTPT'+N+'" id="ACTPT'+N+'" onClick="habilitar_puerto('+N+');" />				';
L=L+'		</th>																';
L=L+'	<th><span id="STATU'+N+'" class="STATU">N/A</span>											';
L=L+'		</th>																';
L=L+'	<th><input disabled value="'+dIP___+'" type="text"	name="IP___'+N+'" id="IP___'+N+'" maxlength="15" size="16" class="IP___" />	';
L=L+'		</th>																';
L=L+'	<th><input disabled value="PRENDER" type="button" name="SWMAN'+N+'" id="SWMAN'+N+'" class="SWMAN" onClick="truchar_estado('+N+');" />	';
L=L+'		</th>																';
L=L+'	<th><select disabled name="RTCMD'+N+'" id="RTCMD'+N+'" onChange="seleccion_de_modos('+N+')" >						';
L=L+'		<option value="DESAC" selected>Desact.</option>											';
L=L+'		<option value="ONOFF">On/Off</option>												';
L=L+'		<option value="RESET">Reset</option>												';
L=L+'		</select>															';
L=L+'		</th>																';
L=L+'	<th><input disabled value="'+dHR_ON+'" type="text" 	name="HR_ON'+N+'" id="HR_ON'+N+'" maxlength="5" size="3" class="HR_HR" />	';
L=L+'		</th>																';
L=L+'	<th><input disabled value="'+dHR_OF+'" type="text" 	name="HR_OF'+N+'" id="HR_OF'+N+'" maxlength="5" size="3" class="HR_HR" />	';
L=L+'		</th>																';
L=L+'	<th><input disabled value="'+dRDLAY+'" type="text" 	name="RDLAY'+N+'" id="RDLAY'+N+'" maxlength="2" size="1" class="RDLAY" />	';
L=L+'		<span class="unidades">seg.</span>												';
L=L+'		</th>																';
L=L+'	<th><input disabled type="checkbox" 		name="RAUTO'+N+'" id="RAUTO'+N+'" onClick="seleccion_de_modos('+N+')" />		';
L=L+'		</th>																';
L=L+'	<th><input disabled value="'+dRPERI+'" type="text"	name="RPERI'+N+'" id="RPERI'+N+'" maxlength="2" size="1" class="RPERI" />	';
L=L+'		<span class="unidades">seg.</span>												';
L=L+'		</th>																';
L=L+'	<th><span class="unidades">N<sub>f</sub> =</span>											';
L=L+'		<input disabled value="'+dRTRIG+'" type="text" 	name="RTRIG'+N+'" id="RTRIG'+N+'" maxlength="1" size="1" class="RTRIG" />	';
L=L+'		</th>																';
L=L+'	<th>																	';
L=L+'		</th>																';
L=L+'	</tr>																	';

	return L;
	}


function boton_aplicar()
{
	var L='<input type="submit" value="APLICAR" name="submit" id="submit" onMouseOver="verifica_datos_fast();" onClick="verifica_datos_full();" />';

	return L;
	}

function switch_debug()
{
	if (document.getElementById('iframe').style.display=='none')
		document.getElementById('iframe').style.display='inline';
	else
		document.getElementById('iframe').style.display='none';
	return;
	}

function verifica_datos_ingresados(N)	//N es el # de puerto
{	
	if (!document.getElementById('ACTPT'+N).checked) return 1;//si el puerto esta desactivado me voy a la mierda

	//tomamos las variables
	var IP___=document.getElementById('IP___'+N).value;
	var RTCMD=document.getElementById('RTCMD'+N).value;
	var HR_ON=document.getElementById('HR_ON'+N).value;
	var HR_OF=document.getElementById('HR_OF'+N).value;
	var RDLAY=document.getElementById('RDLAY'+N).value;
	var RPERI=document.getElementById('RPERI'+N).value;
	var RTRIG=document.getElementById('RTRIG'+N).value;
	//empezamos las verificaciones
	var X=0, Verifica;	//Vars auxiliares temporales
	
	/* IP ---------------------------------------------- */
	//verifica valor
	vIP___=1;	//empiezo por suponer que est� todo bien
	Xn=IP___.split('.');
	for (i=0;i<4;i++) {
		X=parseInt(Xn[i]);	//Obtiene un entero si es que existe
		if (Xn[i]!=X+'')  	//Convierte X a cadena al sumarle la cadena nula
			vIP___=0;	//si no es 100% numerico entero, fracasa
		else if ((i<3) && ((X<0) || (X>255)))
			vIP___=0;	//si es un numero negativo o mayor que 255, fracasa
		else if ((i==3) && ((X==0) || (X==255)))
			vIP___=0;	//si el ultimo octeto contiene una direcci�n broadcast o de red, fracasa
		}
	//corrige si hubo error
	if (vIP___==0) {
		/* document.getElementById('IP___'+N).style.color='red';	//se lo marca en rojo */
		alert('Establecer una direcci�n IP v�lida para el puerto '+N+'.');	//\n   '+MSJ_VAL_VALIDO
		document.getElementById('IP___'+N).value=dIP___;	//se le asigna el valor por default
		}
	/* else	document.getElementById('IP___'+N).style.color='black';	//se lo marca en negro */

	/* HORA ON------------------------------------------- */
	//verifica valor
	vHR_ON=1;	//empiezo por suponer que est� todo bien
	if (HR_ON.length!=5) vHR_ON=0;			//verifico longitud=5
	else if (HR_ON.substr(2,1)!=':') vHR_ON=0;	//verifico caracter separador ":"
	else {							//verifico que el input es numerico
		hh=HR_ON.substr(0,2); mm=HR_ON.substr(3,2);
		if ((isNaN(hh))||(isNaN(mm))) vHR_ON=0;
		else if((parseInt(hh)<0)||(parseInt(hh)>23)||(parseInt(mm)<0)||(parseInt(mm)>59)) vHR_ON=0;
		}
	//corrige si hubo error
	if (vHR_ON==0) {
		/* document.getElementById('HR_ON'+N).style.color='red';	//se lo marca en rojo */
		alert('Error en la Hora ON asignada al puerto '+N+'.\nDeben figurar 2 digitos num�ricos para cada magnitud.\n   '+MSJ_VAL_VALIDO);
		document.getElementById('HR_ON'+N).value=dHR_ON;	//se le asigna el valor por default
		}
	/* else	document.getElementById('HR_ON'+N).style.color='black';	//se lo marca en negro */

	/* HORA OF------------------------------------------- */
	//verifica valor
	vHR_OF=1;	//empiezo por suponer que est� todo bien
	if (HR_OF.length!=5) vHR_OF=0;			//verifico longitud=5
	else if (HR_OF.substr(2,1)!=':') vHR_OF=0;	//verifico caracter separador ":"
	else {							//verifico que el input es numerico
		hh=HR_OF.substr(0,2); mm=HR_OF.substr(3,2);
		if ((isNaN(hh))||(isNaN(mm))) vHR_OF=0;
		else if((parseInt(hh)<0)||(parseInt(hh)>23)||(parseInt(mm)<0)||(parseInt(mm)>59)) vHR_OF=0;
		}
	//corrige si hubo error
	if (vHR_OF==0) {
		/* document.getElementById('HR_OF'+N).style.color='red';	//se lo marca en rojo */
		alert('Error en la Hora OFF/RST asignada al puerto '+N+'.\nDeben figurar 2 digitos num�ricos para cada magnitud\n   '+MSJ_VAL_VALIDO);
		document.getElementById('HR_OF'+N).value=dHR_OF;	//se le asigna el valor por default
		}
	/* else	document.getElementById('HR_OF'+N).style.color='black';	//se lo marca en negro */

	/* HORAS IGUALES-------------------------------------- */
	//verifica valor
	vHR_ID=1;	//empiezo por suponer que est� todo bien
	if((RTCMD=='ONOFF') && (HR_OF==HR_ON)) vHR_ID=0;
	//corrige si hubo error
	if (vHR_ID==0) {
		alert('Error en las horas asignadas al puerto '+N+'.\nLa Hora ON no puede ser igual a la Hora OFF en el modo RTC=On/Off.\n   '+MSJ_VAL_VALIDO);
		document.getElementById('HR_ON'+N).value=dHR_ON;
		document.getElementById('HR_OF'+N).value=dHR_OF;
		}

	
	/* DURACION del RESET--------------------------------- */
	//verifica valor
	vRDLAY=1;	//empiezo por suponer que est� todo bien
	if (isNaN(RDLAY)) vRDLAY=0;
		else if((parseInt(RDLAY)<RDLAYmin)||(parseInt(RDLAY)>RDLAYmax)) vRDLAY=0;
	//corrige si hubo error
	if (vRDLAY==0) {
		/* document.getElementById('RDLAY'+N).style.color='red';	//se lo marca en rojo */
		alert('Error en la duraci�n de RST asignada al puerto '+N+'.\nDebe ser un valor num�rico entre '+RDLAYmin+' y '+RDLAYmax+'.\n   '+MSJ_VAL_VALIDO);
		document.getElementById('RDLAY'+N).value=dRDLAY;	//se le asigna el valor por default
		}
	/* else	document.getElementById('RDLAY'+N).style.color='black';	//se lo marca en negro */

	/* PERIODO ENTRE PINGS-------------------------------- */
	//verifica valor
	vRPERI=1;	//empiezo por suponer que est� todo bien
	if (isNaN(RPERI)) vRPERI=0;
		else if((parseInt(RPERI)<RPERImin)||(parseInt(RPERI)>RPERImax)) vRPERI=0;
	//corrige si hubo error
	if (vRPERI==0) {
		/* document.getElementById('RPERI'+N).style.color='red';	//se lo marca en rojo */
		alert('Error en el intervalo entre PINGs del puerto '+N+'.\nDebe ser un valor num�rico entre '+RPERImin+' y '+RPERImax+'.\n   '+MSJ_VAL_VALIDO);
		document.getElementById('RPERI'+N).value=dRPERI;	//se le asigna el valor por default
		}
	/* else	document.getElementById('RPERI'+N).style.color='black';	//se lo marca en negro */

	/* UMBRAL DE FALLOS TOLERADOS------------------------- */
	//verifica valor
	vRTRIG=1;	//empiezo por suponer que est� todo bien
	if (isNaN(RTRIG)) vRTRIG=0;
		else if((parseInt(RTRIG)<RTRIGmin)||(parseInt(RTRIG)>RTRIGmax)) vRTRIG=0;
	//corrige si hubo error
	if (vRTRIG==0) {
		/* document.getElementById('RTRIG'+N).style.color='red';	//se lo marca en rojo */
		alert('Error en el umbral de fallos del puerto '+N+'.\nDebe ser un valor num�rico entre '+RTRIGmin+' y '+RTRIGmax+'.\n   '+MSJ_VAL_VALIDO);
		document.getElementById('RTRIG'+N).value=dRTRIG;	//se le asigna el valor por default
		}
	/* else	document.getElementById('RTRIG'+N).style.color='black';	//se lo marca en negro */

	/*---------END-OF-VERIFICACIONES------------------------*/
	return verifica_datos_fast();	//todo_ok=(vIP___ & vHR_ON & vHR_OF & vHR_ID & vRDLAY & vRPERI & vRTRIG);
	}


function verifica_datos_fast()
{
	todo_ok=(vIP___ & vHR_ON & vHR_OF & vHR_ID & vRDLAY & vRPERI & vRTRIG);
	if (todo_ok==0) {
		document.getElementById('submit').value='Revisar los Valores';
		document.getElementById('submit').type='button';
		}
	else {
		document.getElementById('submit').value='APLICAR';
		document.getElementById('submit').type='submit';
		}
	return todo_ok;
	}


function verifica_datos_full()
{
	todo_ok=1;
	for(i=1;i<=8;i++) {
		puertoN=verifica_datos_ingresados(i);
		//DEBUG	alert(i+' / '+puertoN);
		todo_ok=(todo_ok & puertoN);
		}
	if (todo_ok==0) {
		document.getElementById('submit').value='Revisar los Valores';
		document.getElementById('submit').type='button';
		}
	else {
		document.getElementById('submit').value='APLICAR';
		document.getElementById('submit').type='submit';
		}
	//DEBUG	alert('Final: '+todo_ok);
	return;
	}
