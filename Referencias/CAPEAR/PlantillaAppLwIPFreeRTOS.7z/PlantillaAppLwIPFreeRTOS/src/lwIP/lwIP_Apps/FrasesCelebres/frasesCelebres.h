/*
 * frasesCelebres.h
 *
 *  Created on: 22/11/2013
 *      Author: Alejandro
 */

#ifndef FRASESCELEBRES_H_
#define FRASESCELEBRES_H_

void InitServidorFrasesCelebres ( void );

#endif /* FRASESCELEBRES_H_ */
